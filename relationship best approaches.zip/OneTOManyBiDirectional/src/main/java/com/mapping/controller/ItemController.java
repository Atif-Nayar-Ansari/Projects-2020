package com.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mapping.dto.CartDTO;
import com.mapping.entity.Cart;
import com.mapping.entity.Item;
import com.mapping.response.Response;
import com.mapping.service.ItemService;



@RestController
@RequestMapping("/item/api")
public class ItemController {

	
		@Autowired
		private ItemService service;
		
		
		@GetMapping("/{id}")
		public ResponseEntity<Response>findItemById(@PathVariable("id") Long id) {
			
			try {
				 
				Item showItemById = service.showItemById(id);
				return new ResponseEntity<Response>(new Response(200, "Success", showItemById), HttpStatus.FOUND);
			} catch (Exception e) {
				return new ResponseEntity<Response>(new Response(400, "failed", "Not Found"), HttpStatus.BAD_REQUEST);
			}
		}
}
