package com.mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.entity.Human;

public interface HumanRepository extends JpaRepository<Human, Long> {

}
