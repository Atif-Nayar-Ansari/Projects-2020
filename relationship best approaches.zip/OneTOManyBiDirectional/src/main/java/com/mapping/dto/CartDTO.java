package com.mapping.dto;

import java.util.List;

public class CartDTO {

	private String CartName;
	private String CartSerialNumber;
	private List<ItemDTO> items;
	
	
	
	
	
	
	
	
	
	
	
	public CartDTO() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public String getCartName() {
		return CartName;
	}
	public void setCartName(String cartName) {
		CartName = cartName;
	}
	public String getCartSerialNumber() {
		return CartSerialNumber;
	}
	public void setCartSerialNumber(String cartSerialNumber) {
		CartSerialNumber = cartSerialNumber;
	}

	public List<ItemDTO> getItems() {
		return items;
	}

	public void setItems(List<ItemDTO> items) {
		this.items = items;
	}

}
