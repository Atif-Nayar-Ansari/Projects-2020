package com.mapping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mapping.entity.Human;
import com.mapping.model.HumanModel;
import com.mapping.response.Response;
import com.mapping.service.HumanService;

@RestController
@RequestMapping("/api/human")
public class HumanController {

	@Autowired
	private HumanService service;
	
	
	@PostMapping
	public ResponseEntity<Response> saveHuman(@RequestBody HumanModel model){
		
		Human saveHuman = service.saveHuman(model);
		
		return new ResponseEntity<Response>(new Response("201", "Human Created with id:"+saveHuman.getHumanId(), saveHuman),HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Response> findHumanById(Long id){
		
		Human humanById = service.getHumanById(id);
		
		return new ResponseEntity<Response>(new Response("200", "Executed Successfully", humanById),HttpStatus.FOUND);
	}
	
	
	@GetMapping
	public ResponseEntity<Response> findAllHuman(){
		
		List<Human> allHuman = service.getAllHuman();
		
		return new ResponseEntity<Response>(new Response("200", "Executed Successfully", allHuman),HttpStatus.FOUND);
	}
}
