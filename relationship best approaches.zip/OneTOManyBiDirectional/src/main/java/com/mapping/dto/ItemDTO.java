package com.mapping.dto;

public class ItemDTO {

	private String itemName;
	private String itemColour;
	private String itemDescription;
	private CartDTO cart;
	
	
	

	public ItemDTO() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemColour() {
		return itemColour;
	}

	public void setItemColour(String itemColour) {
		this.itemColour = itemColour;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}




	public CartDTO getCart() {
		return cart;
	}




	public void setCart(CartDTO cart) {
		this.cart = cart;
	}






	
	
	
}
