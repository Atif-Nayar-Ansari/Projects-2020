package com.mapping.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.dto.CartDTO;
import com.mapping.dto.ItemDTO;
import com.mapping.entity.Cart;
import com.mapping.entity.Item;
import com.mapping.repository.CartRepository;
import com.mapping.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository repo;
	
	@Override
	public Cart saveCart(CartDTO model) {
	  
		
	   Cart cart = new Cart();
	   cart.setCartName(model.getCartName());
	   cart.setCartSerialNumber(model.getCartSerialNumber());
	   
	   List<Item> itemList = new ArrayList<>();
	   List<ItemDTO> items = model.getItems();
	   for (ItemDTO itemDTO : items) {
		   
		   Item entity = new Item();
		   entity.setItemColour(itemDTO.getItemColour());
		   entity.setItemName(itemDTO.getItemName());
		   entity.setItemDescription(itemDTO.getItemDescription());
		   entity.setCart(cart);
		   itemList.add(entity);
	   }
	   cart.setItems(itemList);
	   Cart save = repo.save(cart);
	   return save;
	}

	@Override
	public boolean deleteCart(Long id) {
		repo.deleteById(id);
		return true;
	}

	@Override
	public Cart updateCart(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CartDTO showCartById(Long id) {
		Optional<Cart> findById = repo.findById(id);
		Cart cart = findById.get();
		cart.getItems();
		
		CartDTO model = new CartDTO();
		model.setCartName(cart.getCartName());
		model.setCartSerialNumber(cart.getCartSerialNumber());
		
		List<ItemDTO> itemList = new ArrayList<>();
		List<Item> items = cart.getItems();
		for (Item item : items) {
			ItemDTO idto = new ItemDTO();
			idto.setItemName(item.getItemName());
			idto.setItemColour(item.getItemColour());
			idto.setItemDescription(item.getItemDescription());
			itemList.add(idto);
		}
		model.setItems(itemList);
		return model;
	}

	@Override
	public List<Cart> showAllCart() {
		// TODO Auto-generated method stub
		return null;
	}



}
