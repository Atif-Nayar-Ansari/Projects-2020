package com.validation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.validation.model.EmployeeEntity;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Long> {

	
	
	@Query(value ="SELECT count(*) From EmployeeEntity e WHERE e.name=:name ")
	public Long getNameCount(String name);
}
