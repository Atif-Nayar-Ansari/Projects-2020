package com.mapping.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name = "EARTH_TABLE")
public class Earth { //parent of the relationship

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EARTH_ID")
	private Long earthId;
	
	@Column(name = "COLOUR")
	private String colour;
	
	@Column(name = "SKY")
	private String sky;
	
	@OneToMany(mappedBy = "earth")
	@JsonBackReference
	private List<Human> human = new ArrayList<Human>();
	
	
	
	public Earth() {
		// TODO Auto-generated constructor stub
	}
	
	public Earth(Long earthId, String colour, String sky) {
		super();
		this.earthId = earthId;
		this.colour = colour;
		this.sky = sky;
	}



	public Long getEarthId() {
		return earthId;
	}

	public void setEarthId(Long earthId) {
		this.earthId = earthId;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getSky() {
		return sky;
	}

	public void setSky(String sky) {
		this.sky = sky;
	}

	public List<Human> getHuman() {
		return human;
	}

	public void setHuman(List<Human> human) {
		this.human = human;
	}


}
