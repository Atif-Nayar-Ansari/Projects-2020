package com.validation.service.impl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.validation.dto.EmployeeModel;
import com.validation.model.EmployeeEntity;
import com.validation.repository.EmployeeRepository;
import com.validation.service.EmployeeService;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	
	@Autowired
	private EmployeeRepository repository;
	
	@Override
	public Boolean save(EmployeeModel model) {
		
		EmployeeEntity entity = new EmployeeEntity();
		entity.setName(model.getName());
		entity.setContact(model.getContact());
		entity.setAddress(model.getAddress());
		entity.setEmail(model.getEmail());
		EmployeeEntity save = repository.save(entity);
		if(!Objects.isNull(save)) {
			return true;
		}
		return false;
	}
	@Override
	public Boolean validate(EmployeeModel model) {
		Long nameCount = repository.getNameCount(model.getName());
		
		return nameCount>0;
	}

}
