package com.mapping.response;

import java.util.List;

public class Response {

	private Integer statusCode;
	private String message;
	private Object result;
	
	public Response() {
		// TODO Auto-generated constructor stub
	}

	public Response(Integer statusCode, String message, Object result) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.result = result;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	
	
}
	
