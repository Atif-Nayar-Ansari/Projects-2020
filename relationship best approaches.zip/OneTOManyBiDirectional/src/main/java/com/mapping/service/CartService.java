package com.mapping.service;

import java.util.List;

import com.mapping.dto.CartDTO;
import com.mapping.entity.Cart;

public interface CartService {

	public Cart saveCart(CartDTO model);
	public boolean deleteCart(Long id);
	public Cart updateCart(Long id);
	public CartDTO showCartById(Long id);
	public List<Cart> showAllCart();
}
