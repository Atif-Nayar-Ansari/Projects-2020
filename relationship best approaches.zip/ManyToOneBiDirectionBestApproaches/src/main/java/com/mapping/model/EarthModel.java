package com.mapping.model;

import java.util.List;

public class EarthModel {

	private Long earthId;
	private String colour;
	private String sky;
	private List<HumanModel> human;
	
	
	public EarthModel() {
		// TODO Auto-generated constructor stub
	}
	
	public EarthModel(Long earthId, String colour, String sky, List<HumanModel> human) {
		super();
		this.earthId = earthId;
		this.colour = colour;
		this.sky = sky;
		this.human = human;
	}





	public Long getEarthId() {
		return earthId;
	}

	public void setEarthId(Long earthId) {
		this.earthId = earthId;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getSky() {
		return sky;
	}

	public void setSky(String sky) {
		this.sky = sky;
	}
    
	public List<HumanModel> getHuman() {
		return human;
	}

	public void setHuman(List<HumanModel> human) {
		this.human = human;
	}


}
