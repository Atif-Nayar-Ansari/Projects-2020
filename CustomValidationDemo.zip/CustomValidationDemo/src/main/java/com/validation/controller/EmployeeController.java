package com.validation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.validation.dto.EmployeeModel;
import com.validation.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	
	@PostMapping("/save")
	public ResponseEntity<?> saveEmployee(@Valid @RequestBody EmployeeModel model){// here @Valid will valid at the model class
		
		//validate for the duplicate name
		Boolean validate = service.validate(model);
		if(validate) {
			return new ResponseEntity<String>("Already Existed", HttpStatus.CREATED); 
		}else {
			
			try {
				Boolean save = service.save(model);
				if(save==true) {
					return new ResponseEntity<String>("Saved Successfully", HttpStatus.CREATED);
				}else {
					return new ResponseEntity<String>("Not Saved", HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				return new ResponseEntity<String>("Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}
}
