package com.mapping.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "CART_TABLE")
public class Cart {  //parent of the relationship

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CART_ID")
	private Long CartId;
	
	@Column(name = "CART_NAME")
	private String CartName;
	
	@Column(name = "CART_SERIAL_NUMBER")
	private String CartSerialNumber;
	
	
	@OneToMany(
			   mappedBy = "cart",
			   cascade = CascadeType.ALL,
			   orphanRemoval = true
			   )
	@JsonBackReference
	private List<Item> items; 
	
	
	
	
	//setters and getters and cons
	
	public Cart() {
		// TODO Auto-generated constructor stub
	}






	public Long getCartId() {
		return CartId;
	}






	public void setCartId(Long cartId) {
		CartId = cartId;
	}






	public String getCartName() {
		return CartName;
	}






	public void setCartName(String cartName) {
		CartName = cartName;
	}






	public String getCartSerialNumber() {
		return CartSerialNumber;
	}






	public void setCartSerialNumber(String cartSerialNumber) {
		CartSerialNumber = cartSerialNumber;
	}






	public List<Item> getItems() {
		return items;
	}






	public void setItems(List<Item> items) {
		this.items = items;
	}
	

	
}
