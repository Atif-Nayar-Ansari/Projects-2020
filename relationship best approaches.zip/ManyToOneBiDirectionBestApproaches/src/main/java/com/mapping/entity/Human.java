package com.mapping.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "HUMAN_TABLE")
public class Human { //child of the relationship
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HUMAN_ID")
	private Long humanId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "AGE")
	private Long age;
	
	@ManyToOne
	@JoinColumn(name = "EARTH_ID")
	@JsonManagedReference
	private Earth earth;

	public Human() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Human(Long humanId, String name, Long age, Earth earth) {
		super();
		this.humanId = humanId;
		this.name = name;
		this.age = age;
		this.earth = earth;
	}



	public Long getHumanId() {
		return humanId;
	}

	public void setHumanId(Long humanId) {
		this.humanId = humanId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAge() {
		return age;
	}

	public void setAge(Long age) {
		this.age = age;
	}



	public Earth getEarth() {
		return earth;
	}



	public void setEarth(Earth earth) {
		this.earth = earth;
	}

	
	

}
