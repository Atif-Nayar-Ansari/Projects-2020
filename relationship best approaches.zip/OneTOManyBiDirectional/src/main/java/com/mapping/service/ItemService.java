package com.mapping.service;

import java.util.List;

import com.mapping.dto.ItemDTO;
import com.mapping.entity.Item;

public interface ItemService {

	
	public Item saveItem(ItemDTO model);
	public boolean deleteItem(Long id);
	public Item updateItem(Long id);
	public Item showItemById(Long id);
	public List<Item> showAllItem();
}
