package com.validation.service;

import com.validation.dto.EmployeeModel;

public interface EmployeeService {
	
	public Boolean save(EmployeeModel model);
	public Boolean validate(EmployeeModel model);
}
