package com.mapping.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.entity.Earth;
import com.mapping.entity.Human;
import com.mapping.model.HumanModel;
import com.mapping.repository.HumanRepository;
import com.mapping.service.HumanService;

@Service
public class HumanServiceImpl implements HumanService{

	@Autowired
	private HumanRepository repo;
	
	@Override
	public Human saveHuman(HumanModel model) {
		
		Human human = new Human();
		human.setAge(model.getAge());
		human.setName(model.getName());
		
		
		Earth earth = new Earth();
		
		//only need the id but no need to set all 
		earth.setEarthId(model.getEarth().getEarthId()); 
//		earth.setColour(model.getEarth().getColour());
//		earth.setSky(model.getEarth().getSky());
		human.setEarth(earth);
		Human save = repo.save(human);
		return save;
	}

	@Override
	public Human getHumanById(Long id) {
		Optional<Human> findById = repo.findById(id);
		Human human = findById.get();
		return human;
	}

	@Override
	public List<Human> getAllHuman() {
		
		
		List<Human> findAll = repo.findAll();
		
		return findAll;
	}

}
