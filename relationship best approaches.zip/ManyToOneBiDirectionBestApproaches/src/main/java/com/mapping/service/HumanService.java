package com.mapping.service;

import java.util.List;

import com.mapping.entity.Human;
import com.mapping.model.HumanModel;

public interface HumanService {

	
	public Human saveHuman(HumanModel model);
	public Human getHumanById(Long id);
	public List<Human> getAllHuman();
}
