package com.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomValidationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomValidationDemoApplication.class, args);
	}

}
