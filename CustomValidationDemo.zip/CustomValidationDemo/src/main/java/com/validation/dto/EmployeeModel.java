package com.validation.dto;



import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank; // here import form this package

public class EmployeeModel {

	
	
	@NotBlank(message = "Provide proper name") // this will restrict from null and empty insertion
	@Size(min = 2,message = "size Must be bigger then 2") // if less then 2 then it will fire
	private String  name;
	
	@NotBlank(message = "provide proper email")
	private String email;
	
	
	@Size(min = 5,max = 5,message = "fix is 5")
	private String contact;
	
	@NotBlank(message = "provide address")
	private String address;

	
	public EmployeeModel() {
		// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
