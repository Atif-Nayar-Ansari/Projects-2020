package com.mapping.model;

public class HumanModel {

	private Long humanId;
	private String name;
	private Long age;
	private EarthModel earth;
	
	
	public HumanModel() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public HumanModel(Long humanId, String name, Long age, EarthModel earth) {
		super();
		this.humanId = humanId;
		this.name = name;
		this.age = age;
		this.earth = earth;
	}



	public Long getHumanId() {
		return humanId;
	}
	public void setHumanId(Long humanId) {
		this.humanId = humanId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	
	public EarthModel getEarth() {
		return earth;
	}
	public void setEarth(EarthModel earth) {
		this.earth = earth;
	}
	
	
}
