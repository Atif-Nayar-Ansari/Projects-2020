package com.mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.entity.Earth;

public interface EarthRepository extends JpaRepository<Earth, Long> {

}
