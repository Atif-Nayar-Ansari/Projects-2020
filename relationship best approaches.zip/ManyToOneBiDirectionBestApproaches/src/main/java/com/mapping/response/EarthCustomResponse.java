package com.mapping.response;

import java.util.ArrayList;
import java.util.List;

import com.mapping.entity.Human;

public class EarthCustomResponse {
	
	
	
    private Long earthId;
	private String colour;
	private String sky;
	private List<Human> human = new ArrayList<Human>();
	
	
	
	public EarthCustomResponse() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public EarthCustomResponse(Long earthId, String colour, String sky, List<Human> human) {
		super();
		this.earthId = earthId;
		this.colour = colour;
		this.sky = sky;
		this.human = human;
	}




	public Long getEarthId() {
		return earthId;
	}
	public void setEarthId(Long earthId) {
		this.earthId = earthId;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getSky() {
		return sky;
	}
	public void setSky(String sky) {
		this.sky = sky;
	}
	public List<Human> getHuman() {
		return human;
	}
	public void setHuman(List<Human> human) {
		this.human = human;
	}
	

}
