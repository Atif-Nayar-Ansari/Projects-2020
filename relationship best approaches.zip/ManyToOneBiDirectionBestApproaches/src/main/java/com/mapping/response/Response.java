package com.mapping.response;

public class Response {
	
	private String Status;
	private String message;
	private Object result;
	

	public Response() {
		// TODO Auto-generated constructor stub
	}


	public Response(String status, String message, Object result) {
		super();
		Status = status;
		this.message = message;
		this.result = result;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public Object getResult() {
		return result;
	}


	public void setResult(Object result) {
		this.result = result;
	}
	
}
