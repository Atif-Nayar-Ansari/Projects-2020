package com.mapping.service;

import com.mapping.entity.Earth;
import com.mapping.model.EarthModel;

public interface EarthService {
	
	public Earth earthSave(EarthModel model);
	public EarthModel showAllHumanInEarth(Long id);

}
