package com.mapping.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.dto.ItemDTO;
import com.mapping.entity.Item;
import com.mapping.repository.ItemRepository;
import com.mapping.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {

	
	@Autowired
	private ItemRepository repo;
	
	@Override
	public Item saveItem(ItemDTO model) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteItem(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item updateItem(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Item showItemById(Long id) {
		
		Optional<Item> findById = repo.findById(id);
		if (findById.isPresent()) {
			Item item = findById.get();
			return item;
		}
		return null;
	}

	@Override
	public List<Item> showAllItem() {
		// TODO Auto-generated method stub
		return null;
	}

}
