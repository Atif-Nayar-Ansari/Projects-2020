package com.mapping.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.entity.Earth;
import com.mapping.entity.Human;
import com.mapping.model.EarthModel;
import com.mapping.model.HumanModel;
import com.mapping.repository.EarthRepository;
import com.mapping.service.EarthService;

@Service
public class EarthServiceImpl implements EarthService{

	
	@Autowired
	private EarthRepository repo;
	
	@Override
	public Earth earthSave(EarthModel model) {
		Earth earth = new Earth();
		earth.setColour(model.getColour());
		earth.setSky(model.getSky());
		Earth save = repo.save(earth);
		return save;
	}

	@Override
	public EarthModel showAllHumanInEarth(Long id) {
		Optional<Earth> findById = repo.findById(id);
		Earth earth = findById.get(); //getting earth object which contain all humans
		
		EarthModel emodel = new EarthModel();
		emodel.setEarthId(earth.getEarthId());
		emodel.setColour(earth.getColour());
		emodel.setSky(earth.getSky());

		List<Human> human = earth.getHuman();
		List<HumanModel> list = new ArrayList<>();
		for (Human human2 : human) {
			HumanModel hmodel = new HumanModel();
			hmodel.setAge(human2.getAge());
			hmodel.setHumanId(human2.getHumanId());
			hmodel.setName(human2.getName());
			list.add(hmodel);
		}
		emodel.setHuman(list);
		return emodel;
	}

}
