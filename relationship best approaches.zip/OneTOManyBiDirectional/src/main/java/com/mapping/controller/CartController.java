package com.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mapping.dto.CartDTO;
import com.mapping.entity.Cart;
import com.mapping.response.Response;
import com.mapping.service.CartService;

@RestController
@RequestMapping("/cart/api")
public class CartController {

	@Autowired
	private CartService service;

	@PostMapping
	public ResponseEntity<Response> saveCart(@RequestBody CartDTO model) {

		try {

			Cart saveCart = service.saveCart(model);
			Long cartId = saveCart.getCartId();
			return new ResponseEntity<Response>(new Response(201, "Success", "Cart Saved with ID:" + cartId),
					HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response(201, "Success", "Cart Not Saved"), HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteCart(Long id) {

		try {

			boolean deleteCart = service.deleteCart(id);
			if(deleteCart) {
				return new ResponseEntity<Response>(new Response(200, "Success", "Deleted"),
						HttpStatus.OK);
			}else {
				return new ResponseEntity<Response>(new Response(200, "Failure", "Not Deleted"),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response(500, "Failed", "Server Error"), HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@GetMapping("/{id}")
	public ResponseEntity<Response> findCartById(Long id) {

		try {

			CartDTO showCartById = service.showCartById(id);
				return new ResponseEntity<Response>(new Response(200, "Success", showCartById),
						HttpStatus.OK);
			
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response(500, "Failed", "Server Error"), HttpStatus.BAD_REQUEST);
		}
	}
}
